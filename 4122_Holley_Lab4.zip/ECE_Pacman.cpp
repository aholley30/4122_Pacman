/* Author: Alessandria Holley
 * Class: ECE4122
 * Last Date Modified: 10/29/2020
 * Description: Implements its like-named header file. Allows Pacman to be drawn
 * */
#include <GL/glut.h>
#include <math.h>
#include "ECE_Pacman.h"
#include <iostream>

//draw Pacman
void ECE_Pacman::drawPacMan() {
    glColor3f(1.0, 1.0, 0.0); //yellow
    glPushMatrix();
        glutSolidSphere(0.6, 20, 20); // makes him just big enough to go through maze w/o touching walls
    glPopMatrix();
}