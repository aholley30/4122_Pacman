/* Author: Alessandria Holley
 * Class: ECE4122
 * Last Date Modified: 10/26/2020
 * Description: Header file to define ECE_Pacman class
 * */
class ECE_Pacman {
    public:
        static void drawPacMan();
};