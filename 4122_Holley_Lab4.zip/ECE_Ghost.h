/* Author: Alessandria Holley
 * Class: ECE4122
 * Last Date Modified: 10/26/2020
 * Description: Header file to define ghost class
 * */
class ECE_Ghost {
    public:
        static void drawRedGhost();
        static void drawPinkGhost();
        static void drawGreenGhost();
        static void drawOrangeGhost();
};